# How to contribute 

Please, submit pull request to github.com/telatin/bioinfo/:
this module Proch::N50 is in the Proch-N50 subdirectory

